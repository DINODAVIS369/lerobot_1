import rclpy
from rclpy.node import Node
from geometry_msgs.msg import TwistStamped
from control_msgs.msg import JointJog
from moveit_msgs.srv import ServoCommandType
import sys
import threading
import termios
import tty
import time

# Key bindings
moveBindings = {
    'w': (1,0,0,0,0,0), 's': (-1,0,0,0,0,0),
    'a': (0,1,0,0,0,0), 'd': (0,-1,0,0,0,0),
    'q': (0,0,1,0,0,0), 'e': (0,0,-1,0,0,0),
    'j': (0,0,0,1,0,0), 'l': (0,0,0,-1,0,0),
    'i': (0,0,0,0,1,0), ',': (0,0,0,0,-1,0),
}

jointBindings = {
    '1': (0, 1.0), '2': (0, -1.0),
    '3': (1, 1.0), '4': (1, -1.0),
    '5': (2, 1.0), '6': (2, -1.0),
    '7': (3, 1.0), '8': (3, -1.0),
    '9': (4, 1.0), '0': (4, -1.0),
}

class Teleop(Node):
    def __init__(self):
        super().__init__('keyboard_servo')
        self.twist_pub = self.create_publisher(TwistStamped, '/servo_node/delta_twist_cmds', 10)
        self.joint_pub = self.create_publisher(JointJog, '/servo_node/delta_joint_cmds', 10)
        self.client = self.create_client(ServoCommandType, '/servo_node/switch_command_type')
        
        self.mode = -1 # -1: None, 1: TWIST, 0: JOINT
        self.cmd = [0.0]*6
        self.joint_idx = -1
        self.joint_val = 0.0
        
        self.timer = self.create_timer(0.1, self.publish_cmd)
        self.get_logger().info("Keyboard Servo Node Initialized")

    def switch_mode(self, mode):
        if not self.client.service_is_ready():
            self.get_logger().error("Servo switch service not ready!")
            return
        
        req = ServoCommandType.Request()
        req.command_type = mode
        self.get_logger().info(f"Switching to {'TWIST' if mode==1 else 'JOINT'} mode...")
        self.client.call_async(req)
        self.mode = mode
        time.sleep(0.5) # Wait for Servo to register change

    def publish_cmd(self):
        if self.mode == 1: # TWIST
            if all(v == 0 for v in self.cmd): return
            msg = TwistStamped()
            msg.header.stamp = self.get_clock().now().to_msg()
            msg.header.frame_id = "base_link"
            msg.twist.linear.x = float(self.cmd[0] * 0.2)
            msg.twist.linear.y = float(self.cmd[1] * 0.2)
            msg.twist.linear.z = float(self.cmd[2] * 0.2)
            msg.twist.angular.x = float(self.cmd[3] * 0.5)
            msg.twist.angular.y = float(self.cmd[4] * 0.5)
            msg.twist.angular.z = float(self.cmd[5] * 0.5)
            self.twist_pub.publish(msg)
        elif self.mode == 0: # JOINT
            if self.joint_idx == -1: return
            msg = JointJog()
            msg.header.stamp = self.get_clock().now().to_msg()
            msg.header.frame_id = "base_link"
            msg.joint_names = [f"joint{self.joint_idx+1}"]
            msg.velocities = [float(self.joint_val * 0.5)]
            self.joint_pub.publish(msg)

def main():
    rclpy.init()
    teleop = Teleop()
    
    # Start spinning in a background thread
    spin_thread = threading.Thread(target=rclpy.spin, args=(teleop,), daemon=True)
    spin_thread.start()

    # Terminal handling
    tty_file = None
    try:
        tty_file = open('/dev/tty', 'r')
    except Exception:
        pass
    
    fd = tty_file.fileno() if tty_file else sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    
    print("\n" + "="*40)
    print(" ROBOT KEYBOARD TELEOP ")
    print("="*40)
    print("WSADQE: Move Robot (3D)")
    print("1-0:    Move Joints (Joint 1 to 5)")
    print("SPACE:  Emergency Stop")
    print("CTRL+C: Exit")
    print("="*40)

    try:
        tty.setraw(fd)
        while True:
            key = (sys.stdin.read(1) if not tty_file else tty_file.read(1)).lower()
            
            if key in moveBindings:
                if teleop.mode != 1: teleop.switch_mode(1)
                teleop.cmd = moveBindings[key]
            elif key in jointBindings:
                if teleop.mode != 0: teleop.switch_mode(0)
                teleop.joint_idx, teleop.joint_val = jointBindings[key]
            elif key == ' ' or key == 'k':
                teleop.cmd = [0.0]*6
                teleop.joint_idx = -1
            elif key == '\x03': break
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        if tty_file: tty_file.close()
        teleop.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
